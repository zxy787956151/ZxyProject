<?php 
//使用微信API之前请务必将下面的配置信息改为你自己的
return array(
	'WX_TOKEN'=>'cnsecer',
	'WX_APPID'=>'******',
	'WX_APPSECRET'=>'************************************',	
	'WX_ENCODINGAESKEY'=>'************************************',
	'WX_DOMAIN'=>'http://www.cnsecer.com/',
);
