<?php

namespace Home\Controller;

use Think\Controller;

class PageController extends Controller{

    public function index($name){
        $this->display();
    }
}
